# Principal Component Regression

This is a package I developed to practice creating a full package in Python.